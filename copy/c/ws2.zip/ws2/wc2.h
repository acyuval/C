
void SwapInt (int *, int *);

void SwapSizeT (size_t*, size_t*);

void SwapSizeTPtr (size_t *, size_t *);

int *CopyIntArr(int, int *);

int CheckMemoryloc();

int TestSwapInt();

int TestSwapSizeT();

int TestSwapSizeTPtr();

int TestCopyIntArr();
