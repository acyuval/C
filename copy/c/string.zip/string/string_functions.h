unsigned int MyStrLen(char*);
int MyStrCmp(const char*, const char*);
void TestMyStrCmp();
void TestMyStrLen();

