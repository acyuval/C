#include <stdio.h>
#include <stdlib.h>
#include "string_functions.h"

int main()
{
	TestMyStrCmp();
	TestMyStrLen();
	return 0;
}




